for i in range(10): ## change 10 to get as many lines as you'd like.
    out_list = []
    ## only when i is odd should we add to the output:
    if i%2==1:
	for j in range(i):
	    if j%2==0:
		power = (i-1)//2
		out_list.append(j*10**power)
	print(out_list)

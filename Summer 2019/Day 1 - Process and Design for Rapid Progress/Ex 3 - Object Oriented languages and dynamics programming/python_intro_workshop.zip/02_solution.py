import numpy as np
import matplotlib.pyplot as plt


data = np.loadtxt("test_data.txt")
xs = data[:, 0]
ys = data[:, 1]

plt.plot(xs, ys, 'b.')

fit = np.polyfit(xs,ys,1)
slope, offset = fit

fit_ys = offset + slope*xs
plt.plot(xs,fit_ys, 'k--')